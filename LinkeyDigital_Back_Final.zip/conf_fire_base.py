# Debido a que son muchos servidores y solo un repositorio para mantener las actualizaciones 
# de manera facil, se opto por crear este documento y agregarlo a git.ignore 
# el codigo sacara de aqui las configuraciones principales de firebase o mercado pago... o lo que se necesite 
BOLIVIA_MODE = True
CHILE_MODE = False
BRASIL_MODE = False
PORTUGAL_MODE = False

MODES = ["bob", "cl", "br" , "pg"]

#names of servers: 
bob_conf = "firebaseconfig.json"
cl_conf = "soyyochile-auth-firebase.json"
br_conf = "soueudigital-auth-firebase-brasil.json"
pg_conf = "epadigital-auth-firebase-Portugal.json"

# direccion de los servers: 

bob_server = "https://api.linkey.digital/"
cl_server  = "https://aws.linkey.digital/"
br_server  = "https://api.soueu.com.br/"
pg_server  = "https://api.epadigital.pt/"



# Conf de la DB
DATABASES_CONF = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': 'soyyo',
        'USER': 'postgres',
        'PASSWORD': 'postgres',
        'HOST': '127.0.0.1',
        'PORT': '5432',
    }
}


# Archivo de conf de firebase 
NAME_FIRE_BASE = bob_conf
DOMINIO_NAME = "linkey.digital"
REGION_ACTUAL = "bob"
if CHILE_MODE:
    NAME_FIRE_BASE = cl_conf
    DOMINIO_NAME = "soyyochile.com"
    REGION_ACTUAL = "cl"
elif BRASIL_MODE:
    NAME_FIRE_BASE = br_conf
    DOMINIO_NAME = "soueu.com.br"
    REGION_ACTUAL = "br"
elif PORTUGAL_MODE:
    NAME_FIRE_BASE = pg_conf
    DOMINIO_NAME = "linkey.digital"
    REGION_ACTUAL = "pg"


MERCADOPAGO_SECRET_KEY = 'APP_USR-2751639853842806-031912-14aa9a3792529f1308f6f33dc25f85ac-1727623999'
if BRASIL_MODE:
    MERCADOPAGO_SECRET_KEY = 'APP_USR-2751639853842806-031912-14aa9a3792529f1308f6f33dc25f85ac-1727623999'

# Conf para correo 

if REGION_ACTUAL == "br" :
    EMAIL_HOST = "mail.soueu.com.br"
    EMAIL_PORT = 465
    EMAIL_HOST_USER = "contato@soueu.com.br" 
    EMAIL_HOST_PASSWORD = "V4AUZ0;tEd$3"
else :
    EMAIL_HOST = "mail.dicobol.net "
    EMAIL_PORT = 465
    EMAIL_HOST_USER = "admin@dicobol.net" 
    EMAIL_HOST_PASSWORD = "5qlm_DpgckE7"

