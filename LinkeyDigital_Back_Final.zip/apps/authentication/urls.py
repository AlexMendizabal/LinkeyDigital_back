from rest_framework import routers
from django.urls import path, include
from rest_framework_simplejwt.views import TokenRefreshView

from .views import AuthenticatedView, RegisterUser, CustomerUserViewSet, CustomerUserPutRubroViewSet \
   ,CreateALotOfUsers, CreateAdmin, CustomerAdminViewSet, VerifyToken, AuthenticationSpecialViewset \
    , CustomerUserListViewSet
from .views.list_sponsor_user_viewset import ListSponsorUsersView
from .views.reset_password_viewset import ResetPasswordView, ValidateResetTokenView
from .views.verify_email_viewset import UpdatetemporalEmailView

router = routers.DefaultRouter()

urlpatterns = [
    # public methodds
    path('login', AuthenticatedView.as_view()),

    #private 
    path('register', RegisterUser.as_view()),

    path('user', CustomerUserViewSet.as_view(), name="user_list_or_create_or_update_or_delete"),
    # Metodo para listar a los users (creado especificamente para visualizar a los que no tienen licencia(empresa))
    path('user_list', CustomerUserListViewSet.as_view(), name="user_list"),
    # Metodo para cambiar el rubro de muchos usuarios
    path('rubro', CustomerUserPutRubroViewSet.as_view(), name="user_list_or_create_or_update_or_delete"),

    # Metodo para crear varios usuarios a la vez
    #TODO: que rubro solo edite rubro 
    path('create', CreateALotOfUsers.as_view(), name="register_user"),
    # Metodo para crear un usuario con su licencia 
    path('create-admin', CreateAdmin.as_view(), name="register_user_admin"),
    path('edit-user/<int:customer_id>', CustomerAdminViewSet.as_view(), name="update_user_admin"),

    path('verifyToken', VerifyToken.as_view(), name="verifyEmail"),

    # Metodo para reiniciar users
    path('reset', AuthenticationSpecialViewset.as_view(), name="reset_user"),

    path('sponsors/', ListSponsorUsersView.as_view(), name='list_sponsor_users'),

    # Enlaces para restablecer contraseña de cuentas existentes
    path("reset-password/", ResetPasswordView.as_view(), name="reset-password"),
    path("validate-token/", ValidateResetTokenView.as_view(), name="validate-token"),

    # refrescar token y mantener sesión activa
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    #nuevo método para reemplazar correo temporal por definitivo y establecer contraseña
    path('verify-email/', UpdatetemporalEmailView.as_view(), name='verify_email'),
]